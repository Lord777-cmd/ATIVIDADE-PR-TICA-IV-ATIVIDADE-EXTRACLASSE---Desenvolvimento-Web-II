<?php
require 'includes/db.php';
session_start();
$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = filter_input(INPUT_POST,'email', FILTER_VALIDATE_EMAIL);
    $senha = $_POST['senha'] ?? '';
    if (!$email) $errors[] = 'Email inválido.';
    if (!$senha) $errors[] = 'Senha é obrigatória.';
    if (empty($errors)) {
        $stmt = $pdo->prepare('SELECT * FROM usuarios WHERE email = ?');
        $stmt->execute([$email]);
        $user = $stmt->fetch();
        if ($user && password_verify($senha, $user['senha'])) {
            $_SESSION['user'] = ['id'=>$user['id'],'nome'=>$user['nome'],'email'=>$user['email']];
            header('Location: tasks.php');
            exit;
        } else {
            $errors[] = 'Credenciais inválidas.';
        }
    }
}
require 'includes/header.php';
require 'includes/navbar.php';
?>
<div class="container">
  <h2>Login</h2>
  <?php foreach($errors as $e): ?>
    <div class="error"><?=htmlspecialchars($e)?></div>
  <?php endforeach; ?>
  <form method="post" action="login.php" class="form">
    <label>Email</label>
    <input type="email" name="email" required>
    <label>Senha</label>
    <input type="password" name="senha" required>
    <button type="submit">Entrar</button>
  </form>
  <p>Não tem conta? <a href="register.php">Registrar-se</a></p>
</div>
<?php require 'includes/footer.php'; ?>
