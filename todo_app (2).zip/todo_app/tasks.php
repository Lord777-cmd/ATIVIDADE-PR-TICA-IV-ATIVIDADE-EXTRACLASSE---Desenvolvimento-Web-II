<?php
require 'includes/db.php';
session_start();
if (empty($_SESSION['user'])) {
    header('Location: login.php');
    exit;
}
$user_id = $_SESSION['user']['id'];

// buscar tarefas (filtrar e buscar)
$q_filter = isset($_GET['status']) ? intval($_GET['status']) : null;
$q_search = isset($_GET['q']) ? trim($_GET['q']) : '';

$params = [$user_id];
$sql = 'SELECT id, titulo, descricao, concluida, data_criacao FROM tarefas WHERE usuario_id = ?';
if ($q_filter !== null && ($q_filter === 0 || $q_filter === 1)) {
    $sql .= ' AND concluida = ?'; $params[] = $q_filter;
}
if ($q_search !== '') {
    $sql .= ' AND (titulo LIKE ? OR descricao LIKE ?)';
    $params[] = "%{$q_search}%"; $params[] = "%{$q_search}%";
}
$sql .= ' ORDER BY data_criacao DESC';
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$tarefas = $stmt->fetchAll();

// contagem para gráfico
$stmt1 = $pdo->prepare('SELECT COUNT(*) FROM tarefas WHERE usuario_id = ? AND concluida = 0');
$stmt1->execute([$user_id]);
$pendentes = (int)$stmt1->fetchColumn();
$stmt2 = $pdo->prepare('SELECT COUNT(*) FROM tarefas WHERE usuario_id = ? AND concluida = 1');
$stmt2->execute([$user_id]);
$concluidas = (int)$stmt2->fetchColumn();

require 'includes/header.php';
require 'includes/navbar.php';
?>
<div class="container">
  <h2>Dashboard</h2>

  <div class="card">
    <canvas id="statusChart" width="400" height="150"></canvas>
  </div>

  <div class="card">
    <h3>Nova tarefa</h3>
    <form method="post" action="add_task.php" class="form-inline">
      <input name="titulo" placeholder="Título" required>
      <input name="descricao" placeholder="Descrição (opcional)">
      <button type="submit">Adicionar</button>
    </form>
  </div>

  <div class="card">
    <h3>Minhas tarefas</h3>
    <form method="get" action="tasks.php" class="form-inline">
      <input type="text" name="q" placeholder="Buscar..." value="<?=htmlspecialchars($q_search)?>">
      <select name="status">
        <option value="">Todos</option>
        <option value="0" <?=($q_filter === 0 ? 'selected' : '')?>>Pendentes</option>
        <option value="1" <?=($q_filter === 1 ? 'selected' : '')?>>Concluídas</option>
      </select>
      <button type="submit">Filtrar</button>
    </form>

    <table class="table">
      <thead><tr><th>Título</th><th>Descrição</th><th>Data</th><th>Status</th><th>Ações</th></tr></thead>
      <tbody>
        <?php if (empty($tarefas)): ?>
          <tr><td colspan="5">Nenhuma tarefa encontrada.</td></tr>
        <?php endif; ?>
        <?php foreach($tarefas as $t): ?>
          <tr>
            <td><?=htmlspecialchars($t['titulo'])?></td>
            <td><?=nl2br(htmlspecialchars($t['descricao']))?></td>
            <td><?=htmlspecialchars($t['data_criacao'])?></td>
            <td><?= $t['concluida'] ? 'Concluída' : 'Pendente' ?></td>
            <td class="actions">
              <?php if (!$t['concluida']): ?>
                <a href="toggle_task.php?id=<?= $t['id'] ?>&action=complete" class="btn">Marcar concluída</a>
              <?php else: ?>
                <a href="toggle_task.php?id=<?= $t['id'] ?>&action=uncomplete" class="btn">Marcar pendente</a>
              <?php endif; ?>
              <a href="edit_task.php?id=<?= $t['id'] ?>" class="btn">Editar</a>
              <a href="delete_task.php?id=<?= $t['id'] ?>" class="btn btn-danger" onclick="return confirm('Remover tarefa?')">Remover</a>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<script>
const ctx = document.getElementById('statusChart').getContext('2d');
const statusChart = new Chart(ctx, {
    type: 'doughnut',
    data: {
        labels: ['Pendentes', 'Concluídas'],
        datasets: [{
            data: [<?= $pendentes ?>, <?= $concluidas ?>],
            backgroundColor: ['#f39c12', '#2ecc71']
        }]
    },
    options: { responsive: true, maintainAspectRatio: false }
});
</script>

<?php require 'includes/footer.php'; ?>
