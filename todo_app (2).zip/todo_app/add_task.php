<?php
require 'includes/db.php';
session_start();
if (empty($_SESSION['user'])) { header('Location: login.php'); exit; }
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: tasks.php'); exit; }
$titulo = trim($_POST['titulo'] ?? '');
$descricao = trim($_POST['descricao'] ?? '');
if ($titulo === '') { $_SESSION['flash'] = 'Título obrigatório.'; header('Location: tasks.php'); exit; }
$stmt = $pdo->prepare('INSERT INTO tarefas (usuario_id,titulo,descricao) VALUES (?,?,?)');
$stmt->execute([$_SESSION['user']['id'], $titulo, $descricao]);
header('Location: tasks.php');
exit;
