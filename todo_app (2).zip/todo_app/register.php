<?php
require 'includes/db.php';
session_start();
$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = trim($_POST['nome'] ?? '');
    $email = filter_input(INPUT_POST,'email', FILTER_VALIDATE_EMAIL);
    $senha = $_POST['senha'] ?? '';
    $senha2 = $_POST['senha2'] ?? '';
    if (!$nome) $errors[] = 'Nome é obrigatório.';
    if (!$email) $errors[] = 'Email inválido.';
    if (strlen($senha) < 6) $errors[] = 'Senha precisa ter ao menos 6 caracteres.';
    if ($senha !== $senha2) $errors[] = 'Senhas não conferem.';
    if (empty($errors)) {
        // checar duplicado
        $stmt = $pdo->prepare('SELECT id FROM usuarios WHERE email = ?');
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            $errors[] = 'Email já cadastrado.';
        } else {
            $hash = password_hash($senha, PASSWORD_DEFAULT);
            $ins = $pdo->prepare('INSERT INTO usuarios (nome,email,senha) VALUES (?,?,?)');
            $ins->execute([$nome,$email,$hash]);
            header('Location: login.php');
            exit;
        }
    }
}
require 'includes/header.php';
require 'includes/navbar.php';
?>
<div class="container">
  <h2>Registrar</h2>
  <?php foreach($errors as $e): ?>
    <div class="error"><?=htmlspecialchars($e)?></div>
  <?php endforeach; ?>
  <form method="post" action="register.php" class="form">
    <label>Nome</label>
    <input type="text" name="nome" required>
    <label>Email</label>
    <input type="email" name="email" required>
    <label>Senha</label>
    <input type="password" name="senha" required>
    <label>Confirmar senha</label>
    <input type="password" name="senha2" required>
    <button type="submit">Registrar</button>
  </form>
  <p>Já tem conta? <a href="login.php">Entrar</a></p>
</div>
<?php require 'includes/footer.php'; ?>
