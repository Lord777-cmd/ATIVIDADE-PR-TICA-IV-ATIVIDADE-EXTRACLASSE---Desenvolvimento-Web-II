# To-Do App (Desenvolvimento Web II) - Projeto pronto

Conteúdo:
- Projeto simples em PHP com autenticação e CRUD de tarefas.
- Usa PDO + prepared statements, `password_hash()` e `session_start()`.

**Como usar**
1. Crie o banco de dados usando o arquivo `init_db.sql` (o SQL fornecido pelo seu enunciado está incluído).
   - Exemplo (local): `mysql -u root -p < init_db.sql`
2. Edite `includes/db.php` e ajuste as credenciais do banco de dados (host, dbname, user, pass).
3. Coloque a pasta `todo_app` no seu servidor web (ex: XAMPP `htdocs/`).
4. Acesse pelo navegador: `http://localhost/todo_app/login.php`
5. Cadastre um usuário em `register.php` e comece a usar.

Observações:
- O gráfico na dashboard utiliza Chart.js via CDN.
- Valide e sanitize inputs no servidor (já foi incluído uso de prepared statements).
- Arquivos principais:
  - `login.php`, `register.php`, `tasks.php`
  - `includes/db.php`, `includes/header.php`, `includes/footer.php`, `includes/navbar.php`
  - `assets/styles.css`
