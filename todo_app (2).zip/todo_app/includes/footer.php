
<footer class="footer">
  <p>To-Do App — @DiegoFrancisco</p>
</footer>
</body>
</html>
