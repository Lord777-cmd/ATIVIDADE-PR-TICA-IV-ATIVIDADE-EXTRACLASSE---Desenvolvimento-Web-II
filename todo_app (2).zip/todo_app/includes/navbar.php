<?php
if (session_status() === PHP_SESSION_NONE) session_start();
?>
<nav class="navbar">
  <div class="brand"><a href="tasks.php">To-Do</a></div>
  <div class="nav-items">
    <?php if (!empty($_SESSION['user'])): ?>
      <span>Olá, <?=htmlspecialchars($_SESSION['user']['nome'])?></span>
      <a href="tasks.php">Tarefas</a>
      <a href="logout.php">Sair</a>
    <?php else: ?>
      <a href="login.php">Login</a>
      <a href="register.php">Registrar</a>
    <?php endif; ?>
  </div>
</nav>
