<?php
require 'includes/db.php';
session_start();
if (empty($_SESSION['user'])) { header('Location: login.php'); exit; }
$id = intval($_GET['id'] ?? 0);
if ($id) {
    $stmt = $pdo->prepare('DELETE FROM tarefas WHERE id = ? AND usuario_id = ?');
    $stmt->execute([$id, $_SESSION['user']['id']]);
}
header('Location: tasks.php');
exit;
