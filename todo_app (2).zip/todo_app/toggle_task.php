<?php
require 'includes/db.php';
session_start();
if (empty($_SESSION['user'])) { header('Location: login.php'); exit; }
$id = intval($_GET['id'] ?? 0);
$action = $_GET['action'] ?? '';
if (!$id) header('Location: tasks.php');
if ($action === 'complete') {
    $stmt = $pdo->prepare('UPDATE tarefas SET concluida = 1 WHERE id = ? AND usuario_id = ?');
    $stmt->execute([$id, $_SESSION['user']['id']]);
} elseif ($action === 'uncomplete') {
    $stmt = $pdo->prepare('UPDATE tarefas SET concluida = 0 WHERE id = ? AND usuario_id = ?');
    $stmt->execute([$id, $_SESSION['user']['id']]);
}
header('Location: tasks.php');
exit;
