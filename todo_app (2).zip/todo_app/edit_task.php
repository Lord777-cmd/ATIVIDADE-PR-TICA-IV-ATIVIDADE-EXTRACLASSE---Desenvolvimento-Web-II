<?php
require 'includes/db.php';
session_start();
if (empty($_SESSION['user'])) { header('Location: login.php'); exit; }
$id = intval($_GET['id'] ?? 0);
if (!$id) { header('Location: tasks.php'); exit; }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $titulo = trim($_POST['titulo'] ?? '');
    $descricao = trim($_POST['descricao'] ?? '');
    if ($titulo === '') { $error = 'Título obrigatório.'; }
    else {
        $stmt = $pdo->prepare('UPDATE tarefas SET titulo = ?, descricao = ? WHERE id = ? AND usuario_id = ?');
        $stmt->execute([$titulo, $descricao, $id, $_SESSION['user']['id']]);
        header('Location: tasks.php'); exit;
    }
}

$stmt = $pdo->prepare('SELECT * FROM tarefas WHERE id = ? AND usuario_id = ?');
$stmt->execute([$id, $_SESSION['user']['id']]);
$task = $stmt->fetch();
if (!$task) { header('Location: tasks.php'); exit; }

require 'includes/header.php';
require 'includes/navbar.php';
?>
<div class="container">
  <h2>Editar tarefa</h2>
  <?php if (!empty($error)): ?><div class="error"><?=htmlspecialchars($error)?></div><?php endif; ?>
  <form method="post" action="edit_task.php?id=<?= $id ?>" class="form">
    <label>Título</label>
    <input name="titulo" value="<?=htmlspecialchars($task['titulo'])?>" required>
    <label>Descrição</label>
    <textarea name="descricao"><?=htmlspecialchars($task['descricao'])?></textarea>
    <button type="submit">Salvar</button>
    <a href="tasks.php" class="btn">Cancelar</a>
  </form>
</div>
<?php require 'includes/footer.php'; ?>
