<?php
// redireciona para login ou tasks
session_start();
if (!empty($_SESSION['user'])) header('Location: tasks.php');
else header('Location: login.php');
exit;
